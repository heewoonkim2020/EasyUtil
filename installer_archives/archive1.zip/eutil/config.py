# TODO Enable bug tracking in installer
# TODO Enable accessing config file in installer

code_debugging = False
prod_ready = True
debug_in_line = False
show_output = True